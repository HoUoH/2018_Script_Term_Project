from distutils.core import setup, Extension
setup(name='Movie Info App',
version='1.0',
classifiers = [ 'Movie Info App'],
packages=['Movie Info App'],
)
